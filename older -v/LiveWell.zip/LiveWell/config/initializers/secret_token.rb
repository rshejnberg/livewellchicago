# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
LiveWell::Application.config.secret_token = '516b07066f29cf9449bb8d899594165d8c0bb0a5e1b6596b3a38f729967829cd780d27a593fc4d31dd1a3f2ad61044ab16d0aff6202a68204009bdeded341e5c'

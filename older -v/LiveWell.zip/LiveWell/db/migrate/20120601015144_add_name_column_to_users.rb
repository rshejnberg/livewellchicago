class AddNameColumnToUsers < ActiveRecord::Migration
  def change
    
  end
end

module ApartmentsHelper
end

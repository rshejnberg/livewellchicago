require 'test_helper'

class PhotoAdminControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

require 'test_helper'

class ApartmentImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

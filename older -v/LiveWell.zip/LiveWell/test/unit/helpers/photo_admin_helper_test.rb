require 'test_helper'

class PhotoAdminHelperTest < ActionView::TestCase
end

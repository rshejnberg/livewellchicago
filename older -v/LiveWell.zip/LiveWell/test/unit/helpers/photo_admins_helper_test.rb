require 'test_helper'

class PhotoAdminsHelperTest < ActionView::TestCase
end

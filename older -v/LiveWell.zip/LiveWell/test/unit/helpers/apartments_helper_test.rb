require 'test_helper'

class ApartmentsHelperTest < ActionView::TestCase
end
